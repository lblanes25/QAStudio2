.. include:: README.rst
    :start-after: .. _start-pypi:
    :end-before: .. _end-pypi: