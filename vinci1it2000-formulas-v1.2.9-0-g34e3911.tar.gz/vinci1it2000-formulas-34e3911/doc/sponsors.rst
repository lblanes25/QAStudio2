.. include:: ../README.rst
    :start-after: .. _start-sponsors:
    :end-before: .. _end-sponsors: