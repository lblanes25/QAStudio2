.. schedula documentation master file, created by
   sphinx-quickstart on Sat May 23 16:20:31 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst
    :start-after: .. _start-quick:
    :end-before: .. _end-quick:

.. include:: ../README.rst
    :start-after: .. _start-badges:
    :end-before: .. _end-badges:

.. toctree::
    :maxdepth: 4
    :numbered:
    :caption: Table of Contents
    :name: mastertoc

    doc
    contrib
    sponsors
    api
    change

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`