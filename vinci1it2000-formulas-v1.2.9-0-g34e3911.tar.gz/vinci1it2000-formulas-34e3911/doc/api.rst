API Reference
=============

The core of the library is composed from the following modules:

.. automodule:: formulas