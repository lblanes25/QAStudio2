.. include:: ../README.rst
    :start-after: .. _start-intro:
    :end-before: .. _end-intro: